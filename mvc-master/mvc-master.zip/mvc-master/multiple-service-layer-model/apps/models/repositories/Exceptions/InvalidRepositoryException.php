<?php
namespace Modules\Models\Repositories\Exceptions;

class InvalidRepositoryException extends \Exception
{
    
}
