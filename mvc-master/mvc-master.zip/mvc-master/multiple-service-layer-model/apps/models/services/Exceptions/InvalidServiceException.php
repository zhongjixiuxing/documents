<?php
namespace Modules\Models\Services\Exceptions;

class InvalidServiceException extends \Exception
{
    
}
