<?php

namespace Modules\Backend\Controllers;

class IndexController extends ControllerBase
{

    public function indexAction()
    {

    }

}

