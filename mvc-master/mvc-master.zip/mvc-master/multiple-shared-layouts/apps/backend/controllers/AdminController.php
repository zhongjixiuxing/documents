<?php

namespace Modules\Backend\Controllers;

class AdminController extends ControllerBase
{

    public function indexAction()
    {

    }

}

