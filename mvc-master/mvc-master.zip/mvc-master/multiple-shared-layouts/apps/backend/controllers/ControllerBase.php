<?php

namespace Modules\Backend\Controllers;

class ControllerBase extends \Phalcon\Mvc\Controller
{

}