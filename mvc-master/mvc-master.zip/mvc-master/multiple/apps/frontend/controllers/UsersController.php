<?php

namespace Multiple\Frontend\Controllers;

class UsersController extends \Phalcon\Mvc\Controller
{

	public function indexAction()
	{
		echo '<br>', __METHOD__;
	}

}
