<?php

class Products extends \Phalcon\Mvc\Model
{

	public function getSource()
	{
		return 'products';
	}

}