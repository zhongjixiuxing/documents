<?php

namespace Modules\Frontend\Controllers;

class IndexController extends ControllerBase
{

    public function indexAction()
    {

    }

}

