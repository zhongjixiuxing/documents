<!DOCTYPE html>
<html>
	<head>
		<title>Phalcon PHP Framework</title>
	</head>
	<body>
		<?php echo $this->getContent(); ?>
	</body>
</html>