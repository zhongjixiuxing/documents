<?php

namespace Multiple\Frontend\Controllers;

use Phalcon\Mvc\Controller;

class ControllerBase extends Controller
{

}