<?php

namespace MyApp\Controllers;

class UsersController extends ControllerBase
{

    public function indexAction()
    {
    	echo '[' . __METHOD__ . ']';
    }

}

