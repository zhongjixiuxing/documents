<?php

namespace MyApp\Controllers\Admin;

class UsersController extends ControllerBase
{

    public function indexAction()
    {
    	echo '[' . __METHOD__ . ']';
    }

}

